package com.taweesak.rvfminterface;

public interface MyInterface {
    void MyListener(MyModel myModel);
}
